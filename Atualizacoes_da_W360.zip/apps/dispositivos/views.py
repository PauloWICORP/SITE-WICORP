"""
Views do módulo Dispositivos.

Duas famílias de tela, com públicos diferentes:

    importar / testar   administrador — escolhe quais hosts entram
    painel / lista      cliente — vê o estado das próprias máquinas

O painel do cliente é dividido em duas rotas, mesmo padrão dos relatórios:
a página monta a casca e o navegador busca a lista de 1 em 1 minuto. Assim
a atualização automática não pisca a tela inteira.
"""

import logging

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from apps.core.decorators import somente_admin, somente_wicorp
from apps.core.services import mensagens
from apps.monitoramento.services.zabbix import ZabbixIndisponivel

from .models import Dispositivo, ServidorZabbix
from .services import conexao, graficos, inventario, metricas, sistema
from .services import operacao as servico_operacao

logger = logging.getLogger(__name__)

# De quanto em quanto tempo a tela se atualiza sozinha. Decisão do Paulo
# em 30/07: 1 minuto, que é o mesmo intervalo em que o Zabbix coleta CPU
# e memória. Atualizar mais rápido só gastaria consulta para mostrar
# exatamente o mesmo número.
SEGUNDOS_ATUALIZACAO = 60


@somente_admin
def importar(request, servidor_id):
    """
    Lista os hosts do Zabbix daquele cliente e deixa marcar quais entram.

    Por que uma tela em vez de digitar hostid no cadastro: nas 499
    unidades da fase de links, digitar identificador na mão foi a parte
    mais penosa e a que mais gerou erro. Aqui a W.360 pergunta ao Zabbix
    o que existe e o Paulo só marca.

    Nada é importado sozinho. Host que aparece no Zabbix e não está
    marcado simplesmente não existe para o cliente.
    """
    servidor = get_object_or_404(ServidorZabbix, pk=servidor_id)

    # O que já está importado, indexado por hostid para comparar rápido.
    ja_importados = {d.zabbix_host_id: d for d in servidor.dispositivos.all()}

    if request.method == "POST":
        return _salvar(request, servidor, ja_importados)

    try:
        with conexao.abrir(servidor) as z:
            hosts = z.listar_todos_hosts()
        erro = None
    except ZabbixIndisponivel as falha:
        logger.warning("Importação indisponível em %s: %s", servidor.nome, falha)
        hosts, erro = [], str(falha)

    # Marca o que já está na W.360 para a caixa vir selecionada.
    for host in hosts:
        host["importado"] = host["hostid"] in ja_importados

    return render(request, "dispositivos/importar.html", {
        "titulo_pagina": "Importar dispositivos",
        "menu_ativo": "dispositivos_cadastro",
        "servidor": servidor,
        "hosts": hosts,
        "erro": erro,
        "total_importados": len(ja_importados),
        # Os grupos que aparecem, para o filtro da tela.
        "grupos": sorted({h["grupo"] for h in hosts if h["grupo"]}),
    })


def _salvar(request, servidor, ja_importados: dict):
    """
    Grava a escolha: cria o que foi marcado, remove o que foi desmarcado.

    Remover apaga mesmo o registro. Dá para fazer isso sem medo porque o
    Dispositivo não guarda histórico nenhum — ele é só o apontamento para
    um host do Zabbix. Reimportar recria igual.
    """
    marcados = set(request.POST.getlist("hosts"))

    # Os dados de cada host vêm em campos escondidos do formulário, para
    # não precisar consultar o Zabbix de novo só para saber o nome.
    enviados = request.POST.dict()

    criados = 0
    for hostid in marcados - set(ja_importados):
        Dispositivo.objects.create(
            servidor=servidor,
            zabbix_host_id=hostid,
            nome=enviados.get(f"nome_{hostid}", "") or f"Host {hostid}",
            grupo=enviados.get(f"grupo_{hostid}", ""),
        )
        criados += 1

    removidos = 0
    for hostid in set(ja_importados) - marcados:
        ja_importados[hostid].delete()
        removidos += 1

    # O nome pode ter mudado no Zabbix desde a última importação. A
    # identidade continua sendo o hostid; o nome é só rótulo, então
    # atualizamos sem cerimônia.
    for hostid in marcados & set(ja_importados):
        dispositivo = ja_importados[hostid]
        nome_atual = enviados.get(f"nome_{hostid}", "")
        grupo_atual = enviados.get(f"grupo_{hostid}", "")
        if nome_atual and (dispositivo.nome != nome_atual
                           or dispositivo.grupo != grupo_atual):
            dispositivo.nome = nome_atual
            dispositivo.grupo = grupo_atual
            dispositivo.save(update_fields=["nome", "grupo", "atualizado_em"])

    partes = []
    if criados:
        partes.append(f"{criados} adicionado{'s' if criados > 1 else ''}")
    if removidos:
        partes.append(f"{removidos} removido{'s' if removidos > 1 else ''}")

    messages.success(
        request,
        f"{servidor.nome}: " + (", ".join(partes) if partes else "nada mudou") + "."
    )
    return redirect("dispositivos:importar", servidor_id=servidor.pk)


@somente_admin
def testar_conexao(request, servidor_id):
    """Bate no Zabbix do cliente e diz se o cadastro está funcionando."""
    servidor = get_object_or_404(ServidorZabbix, pk=servidor_id)
    resultado = conexao.testar(servidor)

    if resultado["ok"]:
        messages.success(
            request,
            f"Conexão com {servidor.nome} funcionando. "
            f"Zabbix versão {resultado['versao']}, "
            f"{resultado['total_hosts']} host(s) visíveis para este token."
        )
    else:
        messages.error(request, f"{servidor.nome}: {resultado['erro']}")

    return redirect("dispositivos:importar", servidor_id=servidor.pk)


# ---------------------------------------------------------------------
# Tela do cliente
# ---------------------------------------------------------------------

def _empresa_do_usuario(request):
    """A empresa que o usuário pode ver — e só ela."""
    empresa = getattr(request.user, "empresa", None)
    if empresa is None:
        raise PermissionDenied("Este acesso não está vinculado a nenhuma empresa.")
    return empresa


def _filtrar(dados: dict, busca: str, grupo: str, so_alerta: bool) -> list:
    """
    Filtro em cima do que já veio do Zabbix.

    Filtrar aqui e não na consulta é de propósito: o resumo do topo tem
    que continuar contando TODOS os dispositivos, senão marcar "só em
    alerta" faria o total mudar junto e o número perderia o sentido.
    """
    lista = dados["dispositivos"]

    if so_alerta:
        lista = [d for d in lista if d["estado"] in ("alerta", "sem_comunicacao")]
    if grupo:
        lista = [d for d in lista if d["grupo"] == grupo]
    if busca:
        termo = busca.lower()
        # O nome do cliente entra na busca porque no painel da operação
        # o operador procura por "uniex" tanto quanto por "servidor_ad".
        lista = [d for d in lista
                 if termo in d["nome"].lower()
                 or termo in (d["grupo"] or "").lower()
                 or termo in (d.get("empresa") or "").lower()]
    return lista


@login_required
def painel(request):
    """Estado ao vivo das máquinas do cliente."""
    empresa = _empresa_do_usuario(request)
    dados = metricas.panorama(empresa)

    return render(request, "dispositivos/painel.html", {
        "titulo_pagina": "Dispositivos",
        "menu_ativo": "dispositivos",
        "empresa": empresa,
        "dados": dados,
        "grupos": dados["grupos"],
        "segundos": SEGUNDOS_ATUALIZACAO,
    })


@login_required
def painel_lista(request):
    """
    Só a lista, para o navegador trocar de 1 em 1 minuto.

    O filtro por empresa vale aqui igual à página inteira: quem pede a
    lista recebe a da própria empresa, nunca a de outra.
    """
    empresa = _empresa_do_usuario(request)
    dados = metricas.panorama(empresa)

    lista = _filtrar(
        dados,
        busca=(request.GET.get("busca") or "").strip(),
        grupo=(request.GET.get("grupo") or "").strip(),
        so_alerta=request.GET.get("alerta") == "1",
    )

    return render(request, "dispositivos/_lista.html", {
        "dispositivos": lista,
        "dados": dados,
        "filtrado": len(lista) != dados["resumo"]["total"],
    })


@login_required
def detalhe(request, dispositivo_id):
    """
    Os gráficos de uma máquina, para abrir sobre a lista.

    O filtro por empresa é a proteção que importa aqui: sem ele, trocar o
    número na URL mostraria a máquina de outro cliente. Filtramos pelo
    dono do SERVIDOR, que é onde a empresa realmente mora — o Dispositivo
    não repete esse dado justamente para os dois nunca discordarem.
    """
    if request.user.eh_wicorp:
        # O operador enxerga qualquer máquina — é o mesmo poder que ele
        # já tem no painel de links, e o motivo de a rota ser separada
        # por papel e não por empresa.
        dispositivo = get_object_or_404(Dispositivo, pk=dispositivo_id)
    else:
        empresa = _empresa_do_usuario(request)
        dispositivo = get_object_or_404(
            Dispositivo, pk=dispositivo_id, servidor__empresa=empresa
        )

    dados = graficos.serie_dispositivo(dispositivo)
    # O texto técnico da falha traz o endereço do servidor de
    # monitoramento. Isso é infraestrutura, e não vai para a tela de quem
    # não é da Wicorp — ver core/services/mensagens.py.
    dados["erro"] = mensagens.para(request.user, dados.get("erro"), "dispositivos")

    # Aba "Sistema": ping do agente, processos, threads e tempo ligado.
    # Vem na MESMA requisição dos gráficos, e não numa rota própria,
    # porque este painel se recarrega sozinho de um em um minuto — duas
    # rotas seriam duas idas ao Zabbix a cada renovação, para preencher
    # um painel que o usuário vê inteiro de uma vez.
    sis = sistema.de(dispositivo)
    sis["erro"] = mensagens.para(request.user, sis.get("erro"), "dispositivos")

    return render(request, "dispositivos/_detalhe.html", {
        "d": dados,
        "sis": sis,
        "dispositivo": dispositivo,
        "segundos": SEGUNDOS_ATUALIZACAO,
    })


# ---------------------------------------------------------------------
# Tela do administrador
# ---------------------------------------------------------------------

@somente_admin
def cadastro(request):
    """
    Os Zabbix de dispositivos cadastrados, com o atalho para importar.

    Existe porque o botão de importar vivia na última coluna do admin do
    Django e sumia fora da tela — o Paulo não conseguiu achar em 30/07 e
    teve que entrar pelo endereço direto. Um botão que precisa de rolagem
    horizontal para aparecer é um botão que não existe.
    """
    servidores = (
        ServidorZabbix.objects
        .select_related("empresa")
        .prefetch_related("dispositivos")
        .order_by("empresa__nome", "nome")
    )

    linhas = [{
        "obj": s,
        "total": sum(1 for d in s.dispositivos.all() if d.ativo),
        "inativos": sum(1 for d in s.dispositivos.all() if not d.ativo),
    } for s in servidores]

    return render(request, "dispositivos/cadastro.html", {
        "titulo_pagina": "Dispositivos",
        "menu_ativo": "dispositivos_cadastro",
        "linhas": linhas,
    })


# ---------------------------------------------------------------------
# Painel de dispositivos da operação
# ---------------------------------------------------------------------

def _empresas_pedidas(request):
    """Os ids de empresa marcados no filtro, ignorando lixo na URL."""
    ids = []
    for valor in request.GET.getlist("empresas"):
        try:
            ids.append(int(valor))
        except (TypeError, ValueError):
            continue
    return ids


@somente_wicorp
def operacao(request):
    """
    Todas as máquinas de todos os clientes.

    Mesma tela do cliente, com duas diferenças: mostra o nome do cliente
    em cada cartão, e tem filtro por empresa. O @somente_admin não é
    formalidade — aqui aparece dado de todos os clientes ao mesmo tempo.
    """
    ids = _empresas_pedidas(request)
    dados = servico_operacao.panorama_geral(empresa_ids=ids)

    return render(request, "dispositivos/operacao.html", {
        "titulo_pagina": "Dispositivos",
        "menu_ativo": "dispositivos_operacao",
        "dados": dados,
        "grupos": dados["grupos"],
        "sel_empresas": ids,
        "todas_empresas": servico_operacao._empresas_com_dispositivos(),
        "segundos": SEGUNDOS_ATUALIZACAO,
    })


@somente_wicorp
def operacao_lista(request):
    """Só a lista, para o navegador trocar de 1 em 1 minuto."""
    ids = _empresas_pedidas(request)
    dados = servico_operacao.panorama_geral(empresa_ids=ids)

    lista = _filtrar(
        dados,
        busca=(request.GET.get("busca") or "").strip(),
        grupo=(request.GET.get("grupo") or "").strip(),
        so_alerta=request.GET.get("alerta") == "1",
    )

    return render(request, "dispositivos/_lista.html", {
        "dispositivos": lista,
        "dados": dados,
        "filtrado": len(lista) != dados["resumo"]["total"],
        # É isto que faz o nome do cliente aparecer em cada cartão. Na
        # tela do cliente fica desligado, porque lá só existe um.
        "mostrar_empresa": True,
    })


def _montar_informacoes(request, maquinas, *, eh_operacao: bool) -> dict:
    """
    O contexto da tela de Informações, para os DOIS públicos.

    O cliente vê as máquinas da própria empresa; o operador vê as de
    todos os clientes. A diferença é só QUAIS máquinas entram na lista —
    daí em diante o filtro, o seletor e a tabela são idênticos, e por
    isso moram aqui em vez de estarem escritos duas vezes.

    É o mesmo desenho que `painel`/`operacao` e `painel_lista`/
    `operacao_lista` já usavam: duas views escolhem o conjunto, uma
    função monta a tela.

    O CUSTO É O MESMO NOS DOIS CASOS, e isso não era óbvio: o
    `inventario.todas()` guarda o inventário INTEIRO do Desk numa
    entrada só de cache, indexado por nome de máquina — não é por
    empresa. Então a versão do operador não multiplica consulta por
    cliente, ao contrário do que acontecia na Franquia. É uma leitura de
    cache, com 12 horas de frescor e 48 de validade.
    """
    fichas = inventario.para_muitos(maquinas)

    busca = (request.GET.get("busca") or "").strip().lower()
    grupo = (request.GET.get("grupo") or "").strip()

    # Quais máquinas o usuário escolheu ver. Vem da URL (?m=3&m=7), como
    # os filtros do Dashboard: assim a seleção sobrevive a um F5, pode ir
    # para os favoritos e pode ser mandada para um colega — "olha estas
    # seis máquinas".
    #
    # Lista vazia significa TODAS, e não nenhuma. É a diferença entre
    # "não escolhi" e "escolhi zero", e tratar as duas igual deixaria a
    # tela em branco na primeira visita.
    escolhidas = set()
    for valor in request.GET.getlist("m"):
        try:
            escolhidas.add(int(valor))
        except (TypeError, ValueError):
            continue

    linhas = []
    for maquina in maquinas:
        ficha = fichas.get(maquina.pk, {})
        if escolhidas and maquina.pk not in escolhidas:
            continue
        if grupo and maquina.grupo != grupo:
            continue
        if busca:
            # Procura no nome e também no que a ficha tem: quem digita
            # "i5" quer as máquinas com aquele processador, e quem digita
            # "Windows 11" quer as que ainda não foram atualizadas.
            #
            # Na tela do operador o nome do CLIENTE entra na busca, pelo
            # mesmo motivo da tela ao vivo: lá ele procura por "uniex"
            # tanto quanto por "adm01".
            alvo = " ".join([
                maquina.nome, maquina.grupo or "",
                maquina.servidor.empresa.nome if eh_operacao else "",
                ficha.get("processador", ""), ficha.get("equipamento", ""),
                ficha.get("sistema", ""), ficha.get("modelo", ""),
            ]).lower()
            if busca not in alvo:
                continue
        linhas.append({"maquina": maquina, "f": ficha})

    # A lista do seletor mostra TODAS as máquinas, com a marca de quem
    # está escolhida. Se ela respeitasse o filtro, desmarcar uma faria
    # ela sumir do próprio seletor — e não teria como marcar de volta.
    seletor = [{
        "maquina": m,
        "marcada": (m.pk in escolhidas) if escolhidas else True,
        "tem_ficha": bool(fichas.get(m.pk)),
    } for m in maquinas]

    if eh_operacao:
        url_ao_vivo = reverse("dispositivos:operacao")
        url_esta = reverse("dispositivos:operacao_informacoes")
    else:
        url_ao_vivo = reverse("dispositivos:painel")
        url_esta = reverse("dispositivos:informacoes")

    return {
        "titulo_pagina": "Dispositivos",
        "menu_ativo": "dispositivos_operacao" if eh_operacao else "dispositivos",
        "linhas": linhas,
        "busca": request.GET.get("busca") or "",
        "grupo": grupo,
        "grupos": sorted({m.grupo for m in maquinas if m.grupo}),
        "seletor": seletor,
        "escolhidas": len(escolhidas),
        "total": len(maquinas),
        "com_ficha": sum(1 for l in linhas if l["f"]),
        # As abas e o "Limpar" saem daqui em vez de estarem fixos no
        # template: é o que permite o mesmo arquivo servir as duas áreas
        # sem um `{% if %}` para cada link.
        "url_ao_vivo": url_ao_vivo,
        "url_informacoes": url_esta,
        # Liga a coluna do cliente. Desligado na tela do cliente, porque
        # lá só existe uma empresa — mesma regra do _lista.html.
        "mostrar_empresa": eh_operacao,
        "eh_operacao": eh_operacao,
        "sel_empresas": [],
        "todas_empresas": [],
    }


@login_required
def informacoes(request):
    """
    Ficha de hardware das máquinas do CLIENTE: o que elas são.

    A aba vizinha ("Ao vivo") mostra como cada máquina está agora — CPU,
    memória e disco em uso, lidos do monitoramento. Esta mostra a
    configuração: quanta memória tem, que disco, qual processador, se é
    notebook ou desktop, qual versão do sistema.

    Vem do inventário do Desk, alimentado pelo agente instalado nas
    máquinas. O encontro entre as duas bases é pelo nome do host — ver
    services/inventario.py.

    Não consulta o monitoramento em momento nenhum: se o Zabbix estiver
    fora do ar, esta tela continua inteira.
    """
    empresa = _empresa_do_usuario(request)

    maquinas = list(
        Dispositivo.objects.filter(servidor__empresa=empresa, ativo=True)
        .select_related("servidor")
        .order_by("nome")
    )

    contexto = _montar_informacoes(request, maquinas, eh_operacao=False)
    contexto["empresa"] = empresa
    return render(request, "dispositivos/informacoes.html", contexto)


@somente_wicorp
def operacao_informacoes(request):
    """
    A mesma ficha, de TODOS os clientes — a visão do operador.

    POR QUE ESTA VIEW EXISTE
        A tela ao vivo do operador (`operacao`) não tinha a aba
        Informações que a do cliente tem. Pior: um operador que abrisse
        `/dispositivos/informacoes/` cairia na view do cliente, que
        filtra por `request.user.empresa` — ou seja, veria as máquinas
        da Wicorp, não as dos clientes. A ficha de todos existia no
        inventário e não tinha tela. Visto pelo Paulo em 29/09/2026.

    @somente_wicorp e não @login_required, pelo mesmo motivo da tela ao
    vivo: aqui aparece parque de todos os clientes na mesma página.
    """
    ids = _empresas_pedidas(request)

    consulta = (
        Dispositivo.objects.filter(ativo=True)
        .select_related("servidor", "servidor__empresa")
    )
    if ids:
        consulta = consulta.filter(servidor__empresa__in=ids)

    # Agrupado por cliente e, dentro dele, por nome: é como o operador
    # lê a tabela quando está conferindo o parque de alguém.
    maquinas = list(consulta.order_by("servidor__empresa__nome", "nome"))

    contexto = _montar_informacoes(request, maquinas, eh_operacao=True)
    contexto.update({
        "sel_empresas": ids,
        "todas_empresas": servico_operacao._empresas_com_dispositivos(),
    })
    return render(request, "dispositivos/informacoes.html", contexto)
