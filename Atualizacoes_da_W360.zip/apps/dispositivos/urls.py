"""Rotas do módulo Dispositivos."""

from django.urls import path

from . import views

app_name = "dispositivos"

urlpatterns = [
    # Telas do cliente.
    path("", views.painel, name="painel"),
    path("lista/", views.painel_lista, name="lista"),
    path("informacoes/", views.informacoes, name="informacoes"),

    # Telas de administrador.
    path("operacao/", views.operacao, name="operacao"),
    path("operacao/lista/", views.operacao_lista, name="operacao_lista"),
    # A ficha de hardware de TODOS os clientes. Fica sob "operacao/"
    # de propósito: quem lê a rota vê de quem é a tela.
    path("operacao/informacoes/", views.operacao_informacoes,
         name="operacao_informacoes"),
    path("cadastro/", views.cadastro, name="cadastro"),
    path("cadastro/<int:servidor_id>/", views.importar, name="importar"),
    path("cadastro/<int:servidor_id>/testar/", views.testar_conexao, name="testar"),

    # Gráficos de uma máquina. Vem por último porque o padrão é o mais
    # genérico da lista — se viesse antes, engoliria "operacao" e
    # "cadastro" tentando lê-los como número.
    path("<int:dispositivo_id>/", views.detalhe, name="detalhe"),
]
