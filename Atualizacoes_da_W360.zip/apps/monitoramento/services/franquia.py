"""
Consumo dos links LTE no mês, contra a franquia de 10 GB.

Tela só de operador e administrador. É informação de custo da Wicorp, não
de serviço do cliente.

POR QUE ISTO É CALCULADO E NÃO LIDO
    Procurei no Zabbix principal, em 10/09/2026, itens chamados
    "franquia" e "consumo": ZERO. Não existe um item que diga quanto do
    pacote de dados já foi gasto.

    O que existe é o contador de tráfego da interface LTE, em bits por
    segundo:

        Interface LTE(): Bits received  ==>  net.if.in[ifHCInOctets.8]
        Interface LTE(): Bits sent      ==>  net.if.out[ifHCOutOctets.8]

    Então o consumo do mês é somado por nós: média de cada hora vezes
    3600 segundos, hora após hora, do dia 1º até agora. É a mesma conta
    que o `consumo.py` já faz para o Relatório de Consumo, e é a mesma
    que a operadora faz na fatura.

AS QUATRO DECISÕES, TOMADAS PELO PAULO EM 10/09/2026
    1. Conta DOWNLOAD + UPLOAD. É como Claro e Vivo cobram franquia de
       plano de dados: tudo que passa pelo chip, nos dois sentidos.
    2. O ciclo é o MÊS DO CALENDÁRIO. Zera no dia 1º.
    3. Franquia de 10 GB = 10.240 MB (10 GiB, que é o que a operadora
       entrega). Vermelho a partir de 9.000 MB.
    4. Tela própria no menu, não aba dentro de outra.

POR QUE EM LOTES, E COM ORÇAMENTO DE TEMPO — O ERRO 500 DE 10/09/2026
    A primeira versão pedia a tendência de TODOS os itens de uma vez e o
    Zabbix respondeu HTTP 500. Medido depois, no próprio Zabbix:

        "LTE(): Bits"           608 itens
        "LTE - WICORP(): Bits"   38 itens
                                ---
                                646 itens  =  323 chips

    Um mês de trend são ~720 pontos por item. 646 × 720 = 465.000 linhas
    em UMA resposta — o frontend PHP do Zabbix estoura a memória e
    devolve 500. Não era erro de token nem de rede: era tamanho.

    Daí duas coisas neste arquivo:

    LOTES       a tendência é pedida de LOTE_ITENS em LOTE_ITENS. Se um
                lote falhar mesmo assim, ele é partido no meio e tentado
                de novo — um item problemático não derruba a página
                inteira.

    ORÇAMENTO   26 lotes levam tempo, e o Gunicorn do servidor corta em
                30 segundos. Então a tela tem um orçamento: gasta o que
                pode, mostra o que somou, AVISA que está parcial e
                termina a conta numa thread. A recarga seguinte pega
                tudo pronto do cache.

                É o mesmo desenho que resolveu o 502 da tela de abrir
                chamado, e o mesmo `aquecer_desempenho` que existe para
                o Desempenho — por isso tem um `aquecer_franquia`.

POR QUE O LTE É ACHADO PELO NOME, E NÃO PELA CHAVE
    Esta é a exceção à regra do projeto, e ela precisa estar escrita.

    A chave do item é genérica: `net.if.in[ifHCInOctets.8]`. O número 8 é
    o índice SNMP da interface no roteador e muda de equipamento para
    equipamento. Não há nada na chave que diga "esta é a LTE".

    Quem diz é o NOME, que o Zabbix monta a partir da descrição da
    interface no Mikrotik: "Interface LTE()", "Interface LTE - WICORP()".
    Por isso aqui casamos por nome — e é o mesmo critério que o
    `listar_itens_trafego` do ClienteZabbix já usa há tempos para separar
    principal, backup e LTE (`TERMO_TIPO`).

    Consequência prática: interface de LTE cuja descrição no roteador não
    tenha "LTE" não aparece nesta tela. Se um chip sumir da lista, o
    lugar de olhar é a descrição da interface no Mikrotik.
"""

import logging
import threading
import time
from datetime import datetime, timezone as fuso_utc

from django.core.cache import cache
from django.utils import timezone

from apps.empresas.models import Empresa, Unidade

from .zabbix import ClienteZabbix, ZabbixIndisponivel

logger = logging.getLogger(__name__)

# O consumo do mês só cresce, e devagar: em meia hora um chip de 10 GB
# não muda de faixa de cor. Cache longo porque a conta é caríssima —
# são 26 consultas ao Zabbix.
SEGUNDOS_CACHE = 1800

# Resultado parcial fica guardado pouco tempo: ele existe só para a tela
# não abrir vazia enquanto a thread termina.
SEGUNDOS_CACHE_PARCIAL = 60

# Quantos itens por consulta de tendência. 25 × 720 pontos = 18.000
# linhas por resposta, que o Zabbix entrega sem reclamar. Foi o 500 de
# 10/09 que definiu este número — ver o cabeçalho.
LOTE_ITENS = 25

# Quanto tempo a TELA pode gastar somando. O Gunicorn corta em 30s.
ORCAMENTO_SEGUNDOS = 18

# O comando de aquecimento não tem pressa: ele roda no cron.
SEM_ORCAMENTO = None

# Franquia contratada, em megabytes. 10 GB da operadora é 10 GiB.
FRANQUIA_MB = 10 * 1024          # 10.240 MB

# A partir daqui o cartão fica vermelho. Valor pedido pelo Paulo, fixo em
# megabytes e não em porcentagem: é o número que ele usa para decidir se
# liga para a operadora.
LIMITE_VERMELHO_MB = 9000

# E daqui até o vermelho, âmbar. Não foi pedido, mas um salto de verde
# direto para vermelho esconde justamente a hora de agir.
LIMITE_AMBAR_MB = 7000

TERMO_LTE = "lte"
TERMO_DOWNLOAD = "bits received"
TERMO_UPLOAD = "bits sent"


# ---------------------------------------------------------------------
# Contas
# ---------------------------------------------------------------------

def _inicio_do_mes(agora=None) -> int:
    """
    Meia-noite do dia 1º do mês corrente, como timestamp UTC.

    Usa o fuso configurado no projeto e não UTC cru: "dia 1º" para quem
    olha a tela é o dia 1º em São Paulo, não em Londres.
    """
    agora = agora or timezone.localtime()
    primeiro = agora.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return int(primeiro.astimezone(fuso_utc.utc).timestamp())


def _mb(bits: float) -> float:
    """
    Bits acumulados -> megabytes.

    O Zabbix mede banda em bits por segundo; a operadora cobra em bytes.
    Dividir por 8 e por 1024² é a tradução entre os dois mundos.
    """
    return max(bits, 0.0) / 8 / (1024 * 1024)


def _formatar_mb(mb: float) -> str:
    """2450.7 vira "2,4 GB"; 812.0 vira "812 MB"."""
    if mb >= 1024:
        return f"{mb / 1024:.2f} GB".replace(".", ",")
    return f"{mb:.0f} MB"


def _milhar(n: int) -> str:
    """9000 vira "9.000" — separador de milhar do português."""
    return f"{int(n):,}".replace(",", ".")


def _estado(mb: float) -> str:
    if mb >= LIMITE_VERMELHO_MB:
        return "grave"
    if mb >= LIMITE_AMBAR_MB:
        return "alerta"
    return "ok"


# ---------------------------------------------------------------------
# Em que estado a tela está
# ---------------------------------------------------------------------
#
# POR QUE ISTO EXISTE, E POR QUE AQUI
#
# O template tinha três `{% if %}` independentes — erro, parcial e
# "sem chips" — e eles podiam ser verdadeiros ao mesmo tempo. Em
# 29/09/2026 o Paulo abriu a tela e viu as três coisas juntas:
#
#     0 CHIPS
#     Ainda somando: 0 chip(s) não entraram nesta lista
#     Nenhuma interface LTE encontrada no Zabbix
#
# A terceira frase era falsa: o Zabbix dele tem as interfaces, e as
# devolveu. O que acontecia é que o cabeçalho e a mensagem de vazio
# olhavam para `len(chips)` — chips já SOMADOS — e não para quantos
# foram ENCONTRADOS. Com o cache frio, o orçamento de 18 segundos
# estoura antes da primeira soma, e a tela concluía "não achei nada"
# de um conjunto de centenas de chips.
#
# Agora quem decide é o service, num campo só, e os estados são
# mutuamente exclusivos por construção. O template desenha um bloco por
# estado e não precisa mais raciocinar.

ESTADOS = ("erro", "vazio", "calculando", "sem_consumo", "parcial", "pronto")


def _estado_da_tela(ok: bool, encontrados: int, somados: int,
                    terminou: bool) -> str:
    """
    Um nome para o que a tela tem em mãos. Exaustivo e sem sobreposição.

        erro         não foi possível ler (Zabbix fora, cadastro faltando)
        vazio        o Zabbix respondeu e NÃO tem interface com LTE no nome
        calculando   achou interfaces, o orçamento acabou antes de somar
        sem_consumo  achou interfaces, somou, e não há consumo no período
        parcial      somou parte — a thread está terminando o resto
        pronto       somou tudo
    """
    if not ok:
        return "erro"
    if encontrados == 0:
        return "vazio"
    if somados == 0:
        # A diferença entre estes dois é o `terminou`, e ela importa: um
        # diz "espere", o outro diz "não espere, não tem consumo".
        return "sem_consumo" if terminou else "calculando"
    if somados < encontrados:
        return "parcial"
    return "pronto"


def _resumo_chips(estado: str, encontrados: int, somados: int) -> str:
    """
    A frase do cabeçalho, pronta. Template não conta nem conjuga.

    Um número sozinho ali mentia: "0 chips" com 646 encontrados é falso,
    e "646 chips" com 120 somados também.
    """
    if estado == "vazio":
        return "nenhum chip"
    if estado == "parcial":
        return f"{somados} de {encontrados} chips somados"
    if estado in ("calculando", "sem_consumo"):
        plural = "chip encontrado" if encontrados == 1 else "chips encontrados"
        return f"{encontrados} {plural}"
    return f"{somados} chip" if somados == 1 else f"{somados} chips"


# ---------------------------------------------------------------------
# Ler do Zabbix
# ---------------------------------------------------------------------

def _itens_lte(z, groupids: list[str]) -> dict:
    """
    Os contadores de tráfego das interfaces LTE, em uma consulta.

    Devolve {hostid: {"download": [itemids], "upload": [itemids]}}.

    Lista e não item único de propósito: há roteador com mais de uma
    interface LTE (vi "Interface LTE()" e "Interface LTE - WICORP()" no
    mesmo ambiente). Somamos todas — é o consumo daquele ponto.
    """
    if not groupids:
        return {}

    try:
        itens = z.api.item.get(
            groupids=[str(g) for g in groupids],
            output=["itemid", "name", "key_", "hostid", "value_type"],
            # `search` por NOME e não por chave. Pedir search
            # key_="net.if." trazia TODA interface de TODO host do
            # parque — milhares de itens para descartar quase todos
            # aqui dentro. Buscando "LTE" no nome, o Zabbix já filtra.
            search={"name": TERMO_LTE},
            monitored=True,
        )
    except Exception as erro:
        raise ZabbixIndisponivel(
            f"Erro ao listar as interfaces LTE: {erro}"
        ) from erro

    por_host: dict = {}
    for item in itens:
        nome = (item.get("name") or "").lower()
        if TERMO_LTE not in nome:
            continue
        if TERMO_DOWNLOAD in nome:
            direcao = "download"
        elif TERMO_UPLOAD in nome:
            direcao = "upload"
        else:
            continue  # status, speed, mac e type não são consumo
        por_host.setdefault(str(item["hostid"]), {}) \
                .setdefault(direcao, []).append(str(item["itemid"]))
    return por_host


def _lote_de_tendencia(z, ids: list[str], ts_de: int, ts_ate: int) -> list:
    """
    Um lote de tendência, com corte no meio se o Zabbix reclamar.

    O 500 de 10/09 foi por tamanho de resposta. Se um lote de 25 ainda
    for grande demais para algum item (histórico muito longo, por
    exemplo), partir no meio resolve — e um item problemático deixa de
    derrubar a página inteira.
    """
    try:
        return z.api.trend.get(
            itemids=ids,
            time_from=int(ts_de),
            time_till=int(ts_ate),
            output=["itemid", "value_avg"],
        )
    except Exception as erro:
        if len(ids) <= 1:
            logger.warning("Item %s ficou sem tendência: %s", ids, erro)
            return []
        meio = len(ids) // 2
        logger.info("Lote de %s falhou; partindo no meio. (%s)", len(ids), erro)
        return (_lote_de_tendencia(z, ids[:meio], ts_de, ts_ate)
                + _lote_de_tendencia(z, ids[meio:], ts_de, ts_ate))


def _volume_por_item(z, itemids: list[str], ts_de: int, ts_ate: int,
                     limite_em: float | None = None) -> tuple[dict, bool]:
    """
    Bits trafegados por item no período. Em LOTES — ver o cabeçalho.

    Devolve (total_por_itemid, terminou). `terminou` é False quando o
    orçamento de tempo acabou antes dos lotes — aí quem chama mostra o
    que deu e avisa que está parcial.

    Cada ponto do trend é a média de uma hora em bits/s; média × 3600 dá
    os bits daquela hora. Somar as horas dá o período.
    """
    total: dict = {}
    if not itemids:
        return total, True

    for inicio in range(0, len(itemids), LOTE_ITENS):
        if limite_em is not None and time.monotonic() >= limite_em:
            faltam = len(itemids) - inicio
            logger.info(
                "Orçamento da Franquia esgotado; %s item(ns) ficaram para a thread.",
                faltam,
            )
            return total, False

        lote = itemids[inicio:inicio + LOTE_ITENS]
        for p in _lote_de_tendencia(z, lote, ts_de, ts_ate):
            try:
                iid = str(p["itemid"])
                total[iid] = total.get(iid, 0.0) + float(p["value_avg"]) * 3600
            except (TypeError, ValueError, KeyError):
                continue

    return total, True


# ---------------------------------------------------------------------
# Montar a tela
# ---------------------------------------------------------------------

def _calcular(limite_em: float | None) -> dict:
    """
    A conta em si. `limite_em` é um instante do time.monotonic(); None é
    "sem pressa" (é o que o comando de aquecimento usa).
    """
    grupos = list(
        Empresa.objects.exclude(zabbix_grupo_id="")
        .values_list("zabbix_grupo_id", flat=True)
    )

    base = {
        "ok": False, "erro": "", "parcial": False, "chips": [], "total": 0,
        # `encontrados` é quantos chips o Zabbix DEVOLVEU; `total` é
        # quantos foram somados. Eram a mesma coisa para a tela antiga, e
        # é justamente aí que ela mentia — ver _estado_da_tela().
        "encontrados": 0, "estado": "erro", "resumo_chips": "nenhum chip",
        "faltam_chips": 0,
        "em_alerta": 0, "estourando": 0,
        "franquia_mb": FRANQUIA_MB, "limite_mb": LIMITE_VERMELHO_MB,
        "franquia_texto": _milhar(FRANQUIA_MB),
        "limite_texto": _milhar(LIMITE_VERMELHO_MB),
        "ambar_texto": _milhar(LIMITE_AMBAR_MB),
        "inicio": timezone.localtime().replace(day=1).date(),
    }

    if not grupos:
        base["erro"] = ("Nenhuma empresa tem grupo de host do Zabbix "
                        "configurado, então não há de onde ler o LTE.")
        return base

    ts_de = _inicio_do_mes()
    ts_ate = int(time.time())

    try:
        with ClienteZabbix() as z:
            itens = _itens_lte(z, grupos)
            todos = [
                iid
                for host in itens.values()
                for lista in host.values()
                for iid in lista
            ]
            volumes, terminou = _volume_por_item(z, todos, ts_de, ts_ate, limite_em)
    except ZabbixIndisponivel as erro:
        logger.warning("Franquia indisponível: %s", erro)
        base["erro"] = str(erro)
        return base

    # hostid -> unidade e empresa. Vem do banco e não do Zabbix porque é
    # o nome que a Wicorp usa, e é o mesmo que aparece nas outras telas.
    nomes = {
        u.zabbix_host_id: (u.empresa.nome, u.nome)
        for u in Unidade.objects.select_related("empresa")
                                .filter(zabbix_host_id__in=list(itens))
    }

    chips = []
    for hostid, direcoes in itens.items():
        ids_do_host = [i for lista in direcoes.values() for i in lista]
        # Chip cujos itens ainda não foram somados (orçamento acabou
        # antes de chegar neles) fica FORA da lista. Mostrá-lo com zero
        # seria pior do que não mostrar: pareceria chip sem consumo.
        if not any(i in volumes for i in ids_do_host):
            continue

        download = sum(volumes.get(i, 0.0) for i in direcoes.get("download", []))
        upload = sum(volumes.get(i, 0.0) for i in direcoes.get("upload", []))

        mb_down, mb_up = _mb(download), _mb(upload)
        mb = mb_down + mb_up

        empresa, unidade = nomes.get(hostid, ("—", f"host {hostid}"))
        restante = max(FRANQUIA_MB - mb, 0.0)

        chips.append({
            "hostid": hostid,
            "empresa": empresa,
            "unidade": unidade,
            "mb": mb,
            "texto": _formatar_mb(mb),
            "download_mb": _formatar_mb(mb_down),
            "upload_mb": _formatar_mb(mb_up),
            # Teto de 100 na barra: consumo acima da franquia continua
            # aparecendo em número, mas a barra não vaza do cartão.
            "pct": min(mb / FRANQUIA_MB * 100, 100.0),
            "pct_real": mb / FRANQUIA_MB * 100,
            "estado": _estado(mb),
            "faltam_texto": _formatar_mb(restante),
            "estourou": mb >= FRANQUIA_MB,
        })

    # Mais gasto primeiro. Ninguém abre esta tela para ver quem está bem.
    chips.sort(key=lambda c: -c["mb"])

    encontrados = len(itens)
    somados = len(chips)
    estado = _estado_da_tela(True, encontrados, somados, terminou)

    base.update({
        "ok": True,
        "erro": None,
        "encontrados": encontrados,
        "estado": estado,
        "resumo_chips": _resumo_chips(estado, encontrados, somados),
        # `parcial` agora exige que FALTE alguém. Antes bastava o
        # orçamento ter estourado, e a tela chegava a dizer
        # "ainda somando: 0 chip(s) não entraram nesta lista" — a frase
        # se desmentindo na própria linha.
        "parcial": estado == "parcial",
        "faltam_chips": max(encontrados - somados, 0),
        "inicio": datetime.fromtimestamp(ts_de, fuso_utc.utc).date(),
        "chips": chips,
        "total": somados,
        "em_alerta": sum(1 for c in chips if c["estado"] == "alerta"),
        "estourando": sum(1 for c in chips if c["estado"] == "grave"),
    })
    return base


CHAVE_CACHE = "franquia:mes"

_calculando = False
_trava = threading.Lock()


def _incompleto(d: dict) -> bool:
    """
    A conta não terminou — ainda falta somar chip.

    CUIDADO, E FOI QUASE UM DEFEITO: antes de 29/09 quem decidia isso
    era `d["parcial"]`. Ao passar a exigir `faltam > 0` para o `parcial`,
    o caso "achou 646 e não somou NENHUM" deixaria de ser parcial — e
    então o `do_mes` guardaria esse resultado vazio pelos 30 minutos do
    cache normal e nunca dispararia a thread. A tela ficaria meia hora
    dizendo "somando" com ninguém somando.

    Por isso a decisão passa pelo `estado`, que cobre os dois casos de
    conta inacabada: `calculando` (nada somado) e `parcial` (parte).
    """
    return d.get("estado") in ("calculando", "parcial")


def _completar_ao_fundo():
    """
    Termina a soma numa thread e guarda o resultado completo no cache.

    Mesmo desenho do inventario.py e do analise.py: uma thread só por
    vez, protegida por trava. Sem a trava, cinco operadores abrindo a
    tela ao mesmo tempo sobre cache frio disparariam cinco varreduras
    idênticas de 26 consultas cada.
    """
    global _calculando
    with _trava:
        if _calculando:
            return
        _calculando = True

    def trabalhar():
        global _calculando
        try:
            completo = _calcular(SEM_ORCAMENTO)
            if completo.get("ok") and not _incompleto(completo):
                cache.set(CHAVE_CACHE, completo, SEGUNDOS_CACHE)
                logger.info("Franquia calculada: %s chip(s).", completo["total"])
        except Exception:
            logger.exception("Falha inesperada ao calcular a franquia.")
        finally:
            with _trava:
                _calculando = False

    threading.Thread(target=trabalhar, daemon=True).start()


def do_mes(forcar: bool = False) -> dict:
    """
    Todos os LTE do parque, com o consumo do mês corrente.

    Devolve sempre um dicionário. Nunca levanta exceção.

        {
          "ok": True, "erro": None, "parcial": False,
          "inicio": date,            # dia 1º
          "franquia_mb": 10240, "limite_mb": 9000,
          "chips": [ {...}, ... ],   # do mais gasto para o menos
          "total": 323, "em_alerta": 8, "estourando": 3,
          "faltam_chips": 0,
        }

    `parcial=True` significa que o orçamento de tempo da tela acabou
    antes de somar tudo. Nesse caso uma thread está terminando a conta e
    a próxima recarga vem completa — a tela avisa isso ao usuário.
    """
    if not forcar:
        guardado = cache.get(CHAVE_CACHE)
        if guardado is not None:
            return guardado

    resultado = _calcular(time.monotonic() + ORCAMENTO_SEGUNDOS)

    if resultado.get("ok") and _incompleto(resultado):
        # Guarda o resultado inacabado por POUCO tempo, só para a tela
        # não abrir vazia enquanto a thread trabalha. `_incompleto` e não
        # `parcial`: com nada somado ainda, o estado é "calculando" e o
        # `parcial` é False — ver o comentário de _incompleto().
        cache.set(CHAVE_CACHE, resultado, SEGUNDOS_CACHE_PARCIAL)
        _completar_ao_fundo()
    elif resultado.get("ok"):
        cache.set(CHAVE_CACHE, resultado, SEGUNDOS_CACHE)

    return resultado


def esquecer():
    """Joga o cache fora. Usado pelo comando de aquecimento."""
    cache.delete(CHAVE_CACHE)


def aquecer() -> dict:
    """
    Calcula sem orçamento e guarda. É o que o cron chama.

    Existe pelo mesmo motivo do `aquecer_desempenho`: a conta é de 26
    consultas ao Zabbix, e é melhor que ela aconteça de madrugada do que
    na frente do operador.
    """
    completo = _calcular(SEM_ORCAMENTO)
    if completo.get("ok") and not _incompleto(completo):
        cache.set(CHAVE_CACHE, completo, SEGUNDOS_CACHE)
    return completo
